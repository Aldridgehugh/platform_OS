﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class FCFS
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer2 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer3 = New System.Windows.Forms.Timer(Me.components)
        Me.Timer4 = New System.Windows.Forms.Timer(Me.components)
        Me.txtAverageTime = New System.Windows.Forms.TextBox()
        Me.txtTotalTime = New System.Windows.Forms.TextBox()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.txtWaitingTime_4 = New System.Windows.Forms.TextBox()
        Me.txtWaitingTime_3 = New System.Windows.Forms.TextBox()
        Me.txtWaitingTime_2 = New System.Windows.Forms.TextBox()
        Me.txtWaitingTime_1 = New System.Windows.Forms.TextBox()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.WaitingProcess_4 = New System.Windows.Forms.TextBox()
        Me.WaitingProcess_3 = New System.Windows.Forms.TextBox()
        Me.WaitingProcess_2 = New System.Windows.Forms.TextBox()
        Me.WaitingProcess_1 = New System.Windows.Forms.TextBox()
        Me.lblCPUBurst_5 = New System.Windows.Forms.Label()
        Me.lblCPUBurst_2 = New System.Windows.Forms.Label()
        Me.lblCPUBurst_1 = New System.Windows.Forms.Label()
        Me.lblArrivalTime = New System.Windows.Forms.Label()
        Me.ProgressBar4 = New System.Windows.Forms.ProgressBar()
        Me.ProgressBar3 = New System.Windows.Forms.ProgressBar()
        Me.ProgressBar2 = New System.Windows.Forms.ProgressBar()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.ProcessID_4 = New System.Windows.Forms.TextBox()
        Me.ProcessID_3 = New System.Windows.Forms.TextBox()
        Me.ProcessID_2 = New System.Windows.Forms.TextBox()
        Me.ProcessID_1 = New System.Windows.Forms.TextBox()
        Me.btnStart = New System.Windows.Forms.Button()
        Me.txtCPUBurst_4 = New System.Windows.Forms.TextBox()
        Me.txtCPUBurst_3 = New System.Windows.Forms.TextBox()
        Me.txtCPUBurst_2 = New System.Windows.Forms.TextBox()
        Me.txtCPUBurst_1 = New System.Windows.Forms.TextBox()
        Me.txtProcessID_4 = New System.Windows.Forms.TextBox()
        Me.txtProcessID_3 = New System.Windows.Forms.TextBox()
        Me.txtProcessID_2 = New System.Windows.Forms.TextBox()
        Me.txtProcessID_1 = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.lblCPUBurst_4 = New System.Windows.Forms.Label()
        Me.lblCPUBurst_3 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.txtWaitingTime = New System.Windows.Forms.TextBox()
        Me.SuspendLayout()
        '
        'Timer1
        '
        '
        'Timer2
        '
        '
        'Timer3
        '
        '
        'Timer4
        '
        '
        'txtAverageTime
        '
        Me.txtAverageTime.Location = New System.Drawing.Point(597, 119)
        Me.txtAverageTime.Name = "txtAverageTime"
        Me.txtAverageTime.ReadOnly = True
        Me.txtAverageTime.Size = New System.Drawing.Size(129, 20)
        Me.txtAverageTime.TabIndex = 122
        Me.txtAverageTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtTotalTime
        '
        Me.txtTotalTime.Location = New System.Drawing.Point(597, 144)
        Me.txtTotalTime.Name = "txtTotalTime"
        Me.txtTotalTime.ReadOnly = True
        Me.txtTotalTime.Size = New System.Drawing.Size(129, 20)
        Me.txtTotalTime.TabIndex = 121
        Me.txtTotalTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label21
        '
        Me.Label21.AutoSize = True
        Me.Label21.Location = New System.Drawing.Point(469, 119)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(112, 13)
        Me.Label21.TabIndex = 118
        Me.Label21.Text = "Average Turning Time"
        '
        'Label20
        '
        Me.Label20.AutoSize = True
        Me.Label20.Location = New System.Drawing.Point(485, 147)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(96, 13)
        Me.Label20.TabIndex = 117
        Me.Label20.Text = "Total Waiting Time"
        '
        'txtWaitingTime_4
        '
        Me.txtWaitingTime_4.Location = New System.Drawing.Point(197, 239)
        Me.txtWaitingTime_4.Name = "txtWaitingTime_4"
        Me.txtWaitingTime_4.ReadOnly = True
        Me.txtWaitingTime_4.Size = New System.Drawing.Size(164, 20)
        Me.txtWaitingTime_4.TabIndex = 110
        Me.txtWaitingTime_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtWaitingTime_3
        '
        Me.txtWaitingTime_3.Location = New System.Drawing.Point(197, 213)
        Me.txtWaitingTime_3.Name = "txtWaitingTime_3"
        Me.txtWaitingTime_3.ReadOnly = True
        Me.txtWaitingTime_3.Size = New System.Drawing.Size(164, 20)
        Me.txtWaitingTime_3.TabIndex = 109
        Me.txtWaitingTime_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtWaitingTime_2
        '
        Me.txtWaitingTime_2.ForeColor = System.Drawing.SystemColors.WindowText
        Me.txtWaitingTime_2.Location = New System.Drawing.Point(197, 187)
        Me.txtWaitingTime_2.Name = "txtWaitingTime_2"
        Me.txtWaitingTime_2.ReadOnly = True
        Me.txtWaitingTime_2.Size = New System.Drawing.Size(164, 20)
        Me.txtWaitingTime_2.TabIndex = 108
        Me.txtWaitingTime_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtWaitingTime_1
        '
        Me.txtWaitingTime_1.Location = New System.Drawing.Point(197, 161)
        Me.txtWaitingTime_1.Name = "txtWaitingTime_1"
        Me.txtWaitingTime_1.ReadOnly = True
        Me.txtWaitingTime_1.Size = New System.Drawing.Size(164, 20)
        Me.txtWaitingTime_1.TabIndex = 107
        Me.txtWaitingTime_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label13
        '
        Me.Label13.AutoSize = True
        Me.Label13.Location = New System.Drawing.Point(174, 242)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(13, 13)
        Me.Label13.TabIndex = 105
        Me.Label13.Text = "="
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Location = New System.Drawing.Point(174, 216)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(13, 13)
        Me.Label12.TabIndex = 104
        Me.Label12.Text = "="
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(174, 190)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(13, 13)
        Me.Label11.TabIndex = 103
        Me.Label11.Text = "="
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(174, 165)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(13, 13)
        Me.Label10.TabIndex = 102
        Me.Label10.Text = "="
        '
        'WaitingProcess_4
        '
        Me.WaitingProcess_4.Location = New System.Drawing.Point(39, 239)
        Me.WaitingProcess_4.Name = "WaitingProcess_4"
        Me.WaitingProcess_4.ReadOnly = True
        Me.WaitingProcess_4.Size = New System.Drawing.Size(129, 20)
        Me.WaitingProcess_4.TabIndex = 100
        Me.WaitingProcess_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'WaitingProcess_3
        '
        Me.WaitingProcess_3.Location = New System.Drawing.Point(39, 213)
        Me.WaitingProcess_3.Name = "WaitingProcess_3"
        Me.WaitingProcess_3.ReadOnly = True
        Me.WaitingProcess_3.Size = New System.Drawing.Size(129, 20)
        Me.WaitingProcess_3.TabIndex = 99
        Me.WaitingProcess_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'WaitingProcess_2
        '
        Me.WaitingProcess_2.Location = New System.Drawing.Point(39, 187)
        Me.WaitingProcess_2.Name = "WaitingProcess_2"
        Me.WaitingProcess_2.ReadOnly = True
        Me.WaitingProcess_2.Size = New System.Drawing.Size(129, 20)
        Me.WaitingProcess_2.TabIndex = 98
        Me.WaitingProcess_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'WaitingProcess_1
        '
        Me.WaitingProcess_1.Location = New System.Drawing.Point(39, 161)
        Me.WaitingProcess_1.Name = "WaitingProcess_1"
        Me.WaitingProcess_1.ReadOnly = True
        Me.WaitingProcess_1.Size = New System.Drawing.Size(129, 20)
        Me.WaitingProcess_1.TabIndex = 97
        Me.WaitingProcess_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'lblCPUBurst_5
        '
        Me.lblCPUBurst_5.AutoSize = True
        Me.lblCPUBurst_5.Location = New System.Drawing.Point(617, 116)
        Me.lblCPUBurst_5.Name = "lblCPUBurst_5"
        Me.lblCPUBurst_5.Size = New System.Drawing.Size(0, 13)
        Me.lblCPUBurst_5.TabIndex = 96
        '
        'lblCPUBurst_2
        '
        Me.lblCPUBurst_2.AutoSize = True
        Me.lblCPUBurst_2.Location = New System.Drawing.Point(626, 88)
        Me.lblCPUBurst_2.Name = "lblCPUBurst_2"
        Me.lblCPUBurst_2.Size = New System.Drawing.Size(0, 13)
        Me.lblCPUBurst_2.TabIndex = 93
        '
        'lblCPUBurst_1
        '
        Me.lblCPUBurst_1.AutoSize = True
        Me.lblCPUBurst_1.Location = New System.Drawing.Point(518, 88)
        Me.lblCPUBurst_1.Name = "lblCPUBurst_1"
        Me.lblCPUBurst_1.Size = New System.Drawing.Size(0, 13)
        Me.lblCPUBurst_1.TabIndex = 92
        '
        'lblArrivalTime
        '
        Me.lblArrivalTime.AutoSize = True
        Me.lblArrivalTime.Location = New System.Drawing.Point(418, 88)
        Me.lblArrivalTime.Name = "lblArrivalTime"
        Me.lblArrivalTime.Size = New System.Drawing.Size(0, 13)
        Me.lblArrivalTime.TabIndex = 91
        '
        'ProgressBar4
        '
        Me.ProgressBar4.Location = New System.Drawing.Point(732, 56)
        Me.ProgressBar4.Name = "ProgressBar4"
        Me.ProgressBar4.Size = New System.Drawing.Size(100, 23)
        Me.ProgressBar4.TabIndex = 89
        '
        'ProgressBar3
        '
        Me.ProgressBar3.Location = New System.Drawing.Point(626, 56)
        Me.ProgressBar3.Name = "ProgressBar3"
        Me.ProgressBar3.Size = New System.Drawing.Size(100, 23)
        Me.ProgressBar3.TabIndex = 88
        '
        'ProgressBar2
        '
        Me.ProgressBar2.Location = New System.Drawing.Point(520, 56)
        Me.ProgressBar2.Name = "ProgressBar2"
        Me.ProgressBar2.Size = New System.Drawing.Size(100, 23)
        Me.ProgressBar2.TabIndex = 87
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(413, 56)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(101, 23)
        Me.ProgressBar1.TabIndex = 86
        '
        'ProcessID_4
        '
        Me.ProcessID_4.Location = New System.Drawing.Point(732, 30)
        Me.ProcessID_4.Name = "ProcessID_4"
        Me.ProcessID_4.ReadOnly = True
        Me.ProcessID_4.Size = New System.Drawing.Size(100, 20)
        Me.ProcessID_4.TabIndex = 84
        Me.ProcessID_4.Text = "D"
        Me.ProcessID_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ProcessID_3
        '
        Me.ProcessID_3.Location = New System.Drawing.Point(626, 30)
        Me.ProcessID_3.Name = "ProcessID_3"
        Me.ProcessID_3.ReadOnly = True
        Me.ProcessID_3.Size = New System.Drawing.Size(100, 20)
        Me.ProcessID_3.TabIndex = 83
        Me.ProcessID_3.Text = "C"
        Me.ProcessID_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ProcessID_2
        '
        Me.ProcessID_2.Location = New System.Drawing.Point(520, 30)
        Me.ProcessID_2.Name = "ProcessID_2"
        Me.ProcessID_2.ReadOnly = True
        Me.ProcessID_2.Size = New System.Drawing.Size(100, 20)
        Me.ProcessID_2.TabIndex = 82
        Me.ProcessID_2.Text = "B"
        Me.ProcessID_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'ProcessID_1
        '
        Me.ProcessID_1.Location = New System.Drawing.Point(414, 30)
        Me.ProcessID_1.Name = "ProcessID_1"
        Me.ProcessID_1.ReadOnly = True
        Me.ProcessID_1.Size = New System.Drawing.Size(100, 20)
        Me.ProcessID_1.TabIndex = 81
        Me.ProcessID_1.Text = "A"
        Me.ProcessID_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'btnStart
        '
        Me.btnStart.Location = New System.Drawing.Point(462, 213)
        Me.btnStart.Name = "btnStart"
        Me.btnStart.Size = New System.Drawing.Size(292, 62)
        Me.btnStart.TabIndex = 80
        Me.btnStart.Text = "Compute"
        Me.btnStart.UseVisualStyleBackColor = True
        '
        'txtCPUBurst_4
        '
        Me.txtCPUBurst_4.Location = New System.Drawing.Point(248, 108)
        Me.txtCPUBurst_4.Name = "txtCPUBurst_4"
        Me.txtCPUBurst_4.Size = New System.Drawing.Size(130, 20)
        Me.txtCPUBurst_4.TabIndex = 78
        Me.txtCPUBurst_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtCPUBurst_3
        '
        Me.txtCPUBurst_3.Location = New System.Drawing.Point(248, 82)
        Me.txtCPUBurst_3.Name = "txtCPUBurst_3"
        Me.txtCPUBurst_3.Size = New System.Drawing.Size(130, 20)
        Me.txtCPUBurst_3.TabIndex = 77
        Me.txtCPUBurst_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtCPUBurst_2
        '
        Me.txtCPUBurst_2.Location = New System.Drawing.Point(248, 56)
        Me.txtCPUBurst_2.Name = "txtCPUBurst_2"
        Me.txtCPUBurst_2.Size = New System.Drawing.Size(130, 20)
        Me.txtCPUBurst_2.TabIndex = 76
        Me.txtCPUBurst_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtCPUBurst_1
        '
        Me.txtCPUBurst_1.Location = New System.Drawing.Point(248, 30)
        Me.txtCPUBurst_1.Name = "txtCPUBurst_1"
        Me.txtCPUBurst_1.Size = New System.Drawing.Size(130, 20)
        Me.txtCPUBurst_1.TabIndex = 75
        Me.txtCPUBurst_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtProcessID_4
        '
        Me.txtProcessID_4.Location = New System.Drawing.Point(12, 108)
        Me.txtProcessID_4.Name = "txtProcessID_4"
        Me.txtProcessID_4.ReadOnly = True
        Me.txtProcessID_4.Size = New System.Drawing.Size(100, 20)
        Me.txtProcessID_4.TabIndex = 68
        Me.txtProcessID_4.TabStop = False
        Me.txtProcessID_4.Text = "P4"
        Me.txtProcessID_4.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtProcessID_3
        '
        Me.txtProcessID_3.Location = New System.Drawing.Point(12, 82)
        Me.txtProcessID_3.Name = "txtProcessID_3"
        Me.txtProcessID_3.ReadOnly = True
        Me.txtProcessID_3.Size = New System.Drawing.Size(100, 20)
        Me.txtProcessID_3.TabIndex = 67
        Me.txtProcessID_3.TabStop = False
        Me.txtProcessID_3.Text = "P3"
        Me.txtProcessID_3.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtProcessID_2
        '
        Me.txtProcessID_2.Location = New System.Drawing.Point(12, 56)
        Me.txtProcessID_2.Name = "txtProcessID_2"
        Me.txtProcessID_2.ReadOnly = True
        Me.txtProcessID_2.Size = New System.Drawing.Size(100, 20)
        Me.txtProcessID_2.TabIndex = 66
        Me.txtProcessID_2.TabStop = False
        Me.txtProcessID_2.Text = "P2"
        Me.txtProcessID_2.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'txtProcessID_1
        '
        Me.txtProcessID_1.Location = New System.Drawing.Point(12, 30)
        Me.txtProcessID_1.Name = "txtProcessID_1"
        Me.txtProcessID_1.ReadOnly = True
        Me.txtProcessID_1.Size = New System.Drawing.Size(100, 20)
        Me.txtProcessID_1.TabIndex = 65
        Me.txtProcessID_1.TabStop = False
        Me.txtProcessID_1.Text = "P1"
        Me.txtProcessID_1.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(304, 14)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(57, 13)
        Me.Label3.TabIndex = 64
        Me.Label3.Text = "Burst Time"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(156, 14)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(62, 13)
        Me.Label2.TabIndex = 63
        Me.Label2.Text = "Arrival Time"
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(28, 14)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(48, 13)
        Me.Label1.TabIndex = 62
        Me.Label1.Text = "Process "
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(168, 37)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(13, 13)
        Me.Label4.TabIndex = 125
        Me.Label4.Text = "0"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(168, 56)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(13, 13)
        Me.Label5.TabIndex = 126
        Me.Label5.Text = "0"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(168, 82)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(13, 13)
        Me.Label6.TabIndex = 127
        Me.Label6.Text = "0"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(168, 115)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(13, 13)
        Me.Label7.TabIndex = 128
        Me.Label7.Text = "0"
        '
        'lblCPUBurst_4
        '
        Me.lblCPUBurst_4.AutoSize = True
        Me.lblCPUBurst_4.Location = New System.Drawing.Point(827, 86)
        Me.lblCPUBurst_4.Name = "lblCPUBurst_4"
        Me.lblCPUBurst_4.Size = New System.Drawing.Size(0, 13)
        Me.lblCPUBurst_4.TabIndex = 95
        '
        'lblCPUBurst_3
        '
        Me.lblCPUBurst_3.AutoSize = True
        Me.lblCPUBurst_3.Location = New System.Drawing.Point(736, 85)
        Me.lblCPUBurst_3.Name = "lblCPUBurst_3"
        Me.lblCPUBurst_3.Size = New System.Drawing.Size(0, 13)
        Me.lblCPUBurst_3.TabIndex = 94
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Location = New System.Drawing.Point(469, 173)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(112, 13)
        Me.Label8.TabIndex = 129
        Me.Label8.Text = "Average Waiting Time"
        '
        'txtWaitingTime
        '
        Me.txtWaitingTime.Location = New System.Drawing.Point(597, 173)
        Me.txtWaitingTime.Name = "txtWaitingTime"
        Me.txtWaitingTime.ReadOnly = True
        Me.txtWaitingTime.Size = New System.Drawing.Size(129, 20)
        Me.txtWaitingTime.TabIndex = 130
        Me.txtWaitingTime.TextAlign = System.Windows.Forms.HorizontalAlignment.Center
        '
        'FCFS
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(841, 295)
        Me.Controls.Add(Me.txtWaitingTime)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.txtAverageTime)
        Me.Controls.Add(Me.txtTotalTime)
        Me.Controls.Add(Me.Label21)
        Me.Controls.Add(Me.Label20)
        Me.Controls.Add(Me.txtWaitingTime_4)
        Me.Controls.Add(Me.txtWaitingTime_3)
        Me.Controls.Add(Me.txtWaitingTime_2)
        Me.Controls.Add(Me.txtWaitingTime_1)
        Me.Controls.Add(Me.Label13)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.WaitingProcess_4)
        Me.Controls.Add(Me.WaitingProcess_3)
        Me.Controls.Add(Me.WaitingProcess_2)
        Me.Controls.Add(Me.WaitingProcess_1)
        Me.Controls.Add(Me.lblCPUBurst_5)
        Me.Controls.Add(Me.lblCPUBurst_4)
        Me.Controls.Add(Me.lblCPUBurst_3)
        Me.Controls.Add(Me.lblCPUBurst_2)
        Me.Controls.Add(Me.lblCPUBurst_1)
        Me.Controls.Add(Me.lblArrivalTime)
        Me.Controls.Add(Me.ProgressBar4)
        Me.Controls.Add(Me.ProgressBar3)
        Me.Controls.Add(Me.ProgressBar2)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Controls.Add(Me.ProcessID_4)
        Me.Controls.Add(Me.ProcessID_3)
        Me.Controls.Add(Me.ProcessID_2)
        Me.Controls.Add(Me.ProcessID_1)
        Me.Controls.Add(Me.btnStart)
        Me.Controls.Add(Me.txtCPUBurst_4)
        Me.Controls.Add(Me.txtCPUBurst_3)
        Me.Controls.Add(Me.txtCPUBurst_2)
        Me.Controls.Add(Me.txtCPUBurst_1)
        Me.Controls.Add(Me.txtProcessID_4)
        Me.Controls.Add(Me.txtProcessID_3)
        Me.Controls.Add(Me.txtProcessID_2)
        Me.Controls.Add(Me.txtProcessID_1)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Name = "FCFS"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "First Come First Serve"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents Timer2 As System.Windows.Forms.Timer
    Friend WithEvents Timer3 As System.Windows.Forms.Timer
    Friend WithEvents Timer4 As System.Windows.Forms.Timer
    Friend WithEvents txtAverageTime As System.Windows.Forms.TextBox
    Friend WithEvents txtTotalTime As System.Windows.Forms.TextBox
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents txtWaitingTime_4 As System.Windows.Forms.TextBox
    Friend WithEvents txtWaitingTime_3 As System.Windows.Forms.TextBox
    Friend WithEvents txtWaitingTime_2 As System.Windows.Forms.TextBox
    Friend WithEvents txtWaitingTime_1 As System.Windows.Forms.TextBox
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents WaitingProcess_4 As System.Windows.Forms.TextBox
    Friend WithEvents WaitingProcess_3 As System.Windows.Forms.TextBox
    Friend WithEvents WaitingProcess_2 As System.Windows.Forms.TextBox
    Friend WithEvents WaitingProcess_1 As System.Windows.Forms.TextBox
    Friend WithEvents lblCPUBurst_5 As System.Windows.Forms.Label
    Friend WithEvents lblCPUBurst_2 As System.Windows.Forms.Label
    Friend WithEvents lblCPUBurst_1 As System.Windows.Forms.Label
    Friend WithEvents lblArrivalTime As System.Windows.Forms.Label
    Friend WithEvents ProgressBar4 As System.Windows.Forms.ProgressBar
    Friend WithEvents ProgressBar3 As System.Windows.Forms.ProgressBar
    Friend WithEvents ProgressBar2 As System.Windows.Forms.ProgressBar
    Friend WithEvents ProgressBar1 As System.Windows.Forms.ProgressBar
    Friend WithEvents ProcessID_4 As System.Windows.Forms.TextBox
    Friend WithEvents ProcessID_3 As System.Windows.Forms.TextBox
    Friend WithEvents ProcessID_2 As System.Windows.Forms.TextBox
    Friend WithEvents ProcessID_1 As System.Windows.Forms.TextBox
    Friend WithEvents btnStart As System.Windows.Forms.Button
    Friend WithEvents txtCPUBurst_4 As System.Windows.Forms.TextBox
    Friend WithEvents txtCPUBurst_3 As System.Windows.Forms.TextBox
    Friend WithEvents txtCPUBurst_2 As System.Windows.Forms.TextBox
    Friend WithEvents txtCPUBurst_1 As System.Windows.Forms.TextBox
    Friend WithEvents txtProcessID_4 As System.Windows.Forms.TextBox
    Friend WithEvents txtProcessID_3 As System.Windows.Forms.TextBox
    Friend WithEvents txtProcessID_2 As System.Windows.Forms.TextBox
    Friend WithEvents txtProcessID_1 As System.Windows.Forms.TextBox
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents lblCPUBurst_4 As Label
    Friend WithEvents lblCPUBurst_3 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents txtWaitingTime As TextBox
End Class
